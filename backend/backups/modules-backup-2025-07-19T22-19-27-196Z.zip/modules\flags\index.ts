export * from './services/flags.service';
export * from './types/flags.types';
export * from './validators/flags.validators';

import flagsRoutes from './routes/flags.routes';

export { flagsRoutes };