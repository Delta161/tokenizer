import { Response, NextFunction } from 'express';
import { PrismaClient } from '@prisma/client';
import { AuthenticatedRequest } from '../../auth/requireAuth.js';
import { KycService } from '../services/kyc.service.js';
import { logger } from '../../../utils/logger.js';

const prisma = new PrismaClient();
const kycService = new KycService(prisma);

/**
 * Middleware to require verified KYC status
 * This middleware should be used after requireAuth
 */
export const requireKycVerified = async (
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    if (!req.user?.id) {
      res.status(401).json({
        success: false,
        error: 'Authentication required',
        message: 'You must be logged in to access this resource'
      });
      return;
    }

    const isVerified = await kycService.isKycVerified(req.user.id);

    if (!isVerified) {
      res.status(403).json({
        success: false,
        error: 'KYC verification required',
        message: 'You must complete KYC verification to access this resource',
        kycStatus: 'NOT_VERIFIED'
      });
      return;
    }

    next();
  } catch (error) {
    logger.error('KYC verification middleware error', { module: 'kyc' }, error instanceof Error ? error : new Error(String(error)));
    res.status(500).json({
      success: false,
      error: 'Internal server error',
      message: 'An error occurred while checking KYC verification status'
    });
  }
};